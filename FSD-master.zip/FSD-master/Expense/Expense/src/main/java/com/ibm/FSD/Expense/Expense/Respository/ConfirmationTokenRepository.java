package com.ibm.FSD.Expense.Expense.Respository;

import org.springframework.data.repository.CrudRepository;

import com.ibm.FSD.Expense.Expense.DBModel.ConfirmationToken;
 

public interface ConfirmationTokenRepository extends CrudRepository<ConfirmationToken, String> {
	ConfirmationToken findByConfirmationToken(String confirmationToken);
}

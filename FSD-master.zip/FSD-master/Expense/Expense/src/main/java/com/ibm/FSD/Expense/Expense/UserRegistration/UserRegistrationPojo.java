package com.ibm.FSD.Expense.Expense.UserRegistration;

import lombok.Data;

@Data
public class UserRegistrationPojo {

private String name;

private String Email;
private String password;

private int mobile_number;

 
}

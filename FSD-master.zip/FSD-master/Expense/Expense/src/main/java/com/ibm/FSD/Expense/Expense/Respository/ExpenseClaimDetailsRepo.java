package com.ibm.FSD.Expense.Expense.Respository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.ibm.FSD.Expense.Expense.DBModel.ExpenseClaimDetails;

 

public interface ExpenseClaimDetailsRepo extends MongoRepository<ExpenseClaimDetails, String> {
	List<ExpenseClaimDetails> findByUserId_IdAndCreatedDate(String id,LocalDate today);
}

package com.ibm.FSD.Expense.Expense.Respository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.CrudRepository;

import com.ibm.FSD.Expense.Expense.DBModel.RegisterUser;
import com.ibm.FSD.Expense.Expense.UserRegistration.UserRegistrationPojo;

public interface UserRegistartion extends MongoRepository<RegisterUser, String> {

	 
		
		RegisterUser findByEmailIdAndPassword(String userName,String password);
		
		RegisterUser findByEmailId(String email);
 

}

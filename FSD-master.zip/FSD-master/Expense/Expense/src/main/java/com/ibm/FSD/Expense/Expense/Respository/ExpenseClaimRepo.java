package com.ibm.FSD.Expense.Expense.Respository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.ibm.FSD.Expense.Expense.DBModel.ExpenseClaim;

 

public interface ExpenseClaimRepo extends MongoRepository<ExpenseClaim, String> {

}

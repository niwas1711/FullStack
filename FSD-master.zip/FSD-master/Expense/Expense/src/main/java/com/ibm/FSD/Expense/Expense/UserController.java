package com.ibm.FSD.Expense.Expense;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.FSD.Expense.Expense.DBModel.RegisterUser;
import com.ibm.FSD.Expense.Expense.UserRegistration.Service.RegisterUserRegistartionService;

 

@RestController
public class UserController {
	
	@Autowired
	RegisterUserRegistartionService userService;

	 
	
	@PostMapping("/user")
	public ResponseEntity<RegisterUser> upsertUser(@Valid @RequestBody RegisterUser user,Errors errors){
		URI uri=null;
		try {
			if(user!=null && !errors.hasErrors()) {
				RegisterUser dupUser=userService.findUserByUserEmailId(user.getEmailId());
				if(dupUser==null || dupUser.getId().equals(user.getId()) ) {
					RegisterUser u=userService.saveUser(user);
					if(u!=null) {
						uri = new URI("");
					 
						HttpHeaders responseHeaders = new HttpHeaders();
						responseHeaders.add("message", "Registration Successful");
				 
					    return new ResponseEntity<>(u, responseHeaders, HttpStatus.CREATED);
					}
				}else {
					String errorMessage="User already exists";
					return ResponseEntity.status(HttpStatus.CONFLICT).header("error", errorMessage).build();
				}
				
			}else if(errors!=null) {
				String errorMessage=errors.getAllErrors().stream().map(p->p.getDefaultMessage()).collect(Collectors.joining(","));
				return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
						.header("message", errorMessage).build();
			}
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ResponseEntity.created(uri).build();
		
	}
	@PostMapping("/login")
	public ResponseEntity<RegisterUser> login(HttpServletRequest httpServletRequest){
		URI uri=null;
		try {
			String userName=httpServletRequest.getParameter("username");
			String password=httpServletRequest.getParameter("password");
			if(userName!=null && !userName.isEmpty() && password!=null && !password.isEmpty()) {
				RegisterUser u=userService.findUserByUserName(userName,password);
				if(u!=null) {
				 
					uri = new URI("");
					HttpHeaders responseHeaders = new HttpHeaders();
					responseHeaders.add("message", "Login Successful");
					 
				    return new ResponseEntity<>(u, responseHeaders, HttpStatus.OK);
				}
			}else {
				return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
						.header("message", "Invalid Credentails").build();
			}
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ResponseEntity.notFound().build();
		
	}
	@GetMapping("/user/{id}")
	public ResponseEntity<RegisterUser> getUserForId(@PathVariable String id){
		try {
			if(id!=null && !id.isEmpty()) {
				RegisterUser u=userService.getUeserForId(id);
				if(u!=null) {
					return ResponseEntity.status(HttpStatus.OK).header("message", "User retrieved successfully.").body(u);
				}
			}else  {
				String errorMessage="ID can not be empty";
				return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
						.header("message", errorMessage).build();
			}
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ResponseEntity.notFound().build();
		
	}
	@GetMapping("/user")
	public ResponseEntity<List<RegisterUser>> getUsers(){
		try {
				List<RegisterUser> list=userService.getUesers();
					return ResponseEntity.ok(list);
			
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ResponseEntity.notFound().build();
		
	}
	@DeleteMapping("/user/{id}")
	public ResponseEntity<RegisterUser> deleteUser(@PathVariable String id){
		try {
			if(id!=null && !id.isEmpty()) {
				boolean isDeleted=userService.deleteUser(id);
				if(isDeleted) {
					return ResponseEntity.ok().build();
				}
			}else  {
				String errorMessage="ID can not be empty";
				return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
						.header("message", errorMessage).build();
			}
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ResponseEntity.notFound().build();
		
	}

}

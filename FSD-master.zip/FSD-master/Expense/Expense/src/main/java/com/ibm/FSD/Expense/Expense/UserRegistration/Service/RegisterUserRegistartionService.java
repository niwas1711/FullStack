package com.ibm.FSD.Expense.Expense.UserRegistration.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Sort;
import com.ibm.FSD.Expense.Expense.DBModel.RegisterUser;
import com.ibm.FSD.Expense.Expense.Respository.UserRegistartion;

 

@Service
public class RegisterUserRegistartionService  {

	@Autowired
private UserRegistartion RegisterUserRegistartion;
	
	public RegisterUser saveUser(RegisterUser RegisterUser) {
		RegisterUser bo=RegisterUserRegistartion.save(RegisterUser);
		if(RegisterUser.getId()==null && RegisterUser.getEmailId()!=null && !RegisterUser.getEmailId().isEmpty()
				&& bo!=null) {
			requestEmailConfirmation(bo);
		}
		return bo;
	}
	public void requestEmailConfirmation(RegisterUser RegisterUser) {
		String toEmailId="";
		String subject="Verify Email Id";
		String body="Please verfiy your email id by clicking below link";
		
	}
	public boolean  deleteUser(String id) {
		RegisterUserRegistartion.deleteById(id);
		 return true;
	}
	
	public RegisterUser getUeserForId(String userId) {
		return RegisterUserRegistartion.findById(userId).get();
	}
	public List<RegisterUser> getUesers() {
		return RegisterUserRegistartion.findAll(Sort.by("mobileNo"));
	}
	public RegisterUser findUserByUserName(String userName, String password) {
		// TODO Auto-generated method stub
		return RegisterUserRegistartion.findByEmailIdAndPassword(userName,password);
	}
	public RegisterUser findUserByUserEmailId(String emailId) {
		return RegisterUserRegistartion.findByEmailId(emailId);
	}
	
	
}

package com.ibm.FSD.Expense.Report.ReportService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReportServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

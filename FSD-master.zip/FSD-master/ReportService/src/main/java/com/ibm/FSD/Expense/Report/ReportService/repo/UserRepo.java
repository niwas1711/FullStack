package com.ibm.FSD.Expense.Report.ReportService.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.ibm.FSD.Expense.Report.ReportService.Entity.RegisterUser;

 

public interface UserRepo extends MongoRepository<RegisterUser, String>{

}

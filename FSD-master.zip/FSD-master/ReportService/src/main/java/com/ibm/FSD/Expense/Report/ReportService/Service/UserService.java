package com.ibm.FSD.Expense.Report.ReportService.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.ibm.FSD.Expense.Report.ReportService.Entity.RegisterUser;
import com.ibm.FSD.Expense.Report.ReportService.repo.UserRepo;

 

@Service
public class UserService {
	
	@Autowired
	UserRepo userRepo;
	

	public List<RegisterUser> getUesers() {
		return userRepo.findAll(Sort.by("mobileNo"));
	}
	

}

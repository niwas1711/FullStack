package com.ibm.FSD.Expense.Report.ReportService.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.ibm.FSD.Expense.Report.ReportService.Entity.ExpenseClaimDetails;

 

public interface ExpenseClaimDetailsRepo extends MongoRepository<ExpenseClaimDetails, String> {

}

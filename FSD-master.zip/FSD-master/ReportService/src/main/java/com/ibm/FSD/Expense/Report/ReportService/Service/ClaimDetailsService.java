package com.ibm.FSD.Expense.Report.ReportService.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.FSD.Expense.Report.ReportService.Entity.ExpenseClaimDetails;
import com.ibm.FSD.Expense.Report.ReportService.repo.ExpenseClaimDetailsRepo;

 

@Service
public class ClaimDetailsService {
	
	@Autowired
	ExpenseClaimDetailsRepo expenseClaimDetailsRepo;
	

	public List<ExpenseClaimDetails> getAllExpenseClaimDetails() {
		return expenseClaimDetailsRepo.findAll();
	}

}

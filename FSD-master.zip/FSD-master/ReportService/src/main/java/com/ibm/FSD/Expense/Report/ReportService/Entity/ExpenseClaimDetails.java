package com.ibm.FSD.Expense.Report.ReportService.Entity;

import java.io.Serializable;
import java.time.LocalDate;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Document
 @Data
public class ExpenseClaimDetails  implements Serializable{
	
	private String id;
	
	private String expenseDetailName;
	private String description;
	private String typeOfExpense;
	private String paymentMode;
	
	private ExpenseClaim expenseClaimId;
	private RegisterUser userId;
	
	@CreatedDate
	private LocalDate createdDate;
	@LastModifiedDate
	private LocalDate  lastModifiedDate;

}

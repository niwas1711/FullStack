package com.ibm.FSD.Expense.Report.ReportService.Entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import lombok.Data;

@Entity
@Data
public class RegisterUser {
	private String id;
	private String userName;
	@NotEmpty(message = "Mobile Number can not be empty")
	private String mobileNo;
	@NotEmpty(message = "Email can not be empty")
	private String emailId;
	@NotEmpty(message = "Password can not be empty")
	private String password;
	
	@CreatedDate
	private LocalDate createdDate;

	@LastModifiedDate
	private LocalDate  lastModifiedDate;
}

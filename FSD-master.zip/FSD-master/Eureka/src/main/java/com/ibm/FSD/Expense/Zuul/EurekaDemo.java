 package com.ibm.FSD.Expense.Zuul;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class EurekaDemo {

	public static void main(String[] args) {
		SpringApplication.run(EurekaDemo.class, args);
	}

}

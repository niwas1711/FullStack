export interface Tenant {
    id:number;
    name: string;
  }